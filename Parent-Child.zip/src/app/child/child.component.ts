import { Component, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
  inputs:['Pdata'],
  outputs:['childevent']
})
export class ChildComponent implements OnInit {
  Pdata:any;
  childevent=new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }
  // onChange(val: any) {
  //   console.log(val);
  //   this.childevent.emit(val);
  // }
}
