// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
   firebaseConfig : {

    apiKey: "AIzaSyDsc_OsZCb20qMScgkCvpjkxvtg8XY4MKI",
  
    authDomain: "pushnotification-70393.firebaseapp.com",
  
    projectId: "pushnotification-70393",
  
    storageBucket: "pushnotification-70393.appspot.com",
  
    messagingSenderId: "833472973108",
  
    appId: "1:833472973108:web:7040b1909f516ec4cffd61",

    vapidKey: "BPGRHfQ_oHFxGSQ7RgPmR8qmHdTa40n-Fk3tH97yrzBgbBvm8TMDXnKuXj1oJsHwpCcy8UGRXAhYmXHW_VIPxDw"
  
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
