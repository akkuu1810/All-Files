export const environment = {
   firebaseConfig : {

    apiKey: "AIzaSyDsc_OsZCb20qMScgkCvpjkxvtg8XY4MKI",
  
    authDomain: "pushnotification-70393.firebaseapp.com",
  
    projectId: "pushnotification-70393",
  
    storageBucket: "pushnotification-70393.appspot.com",
  
    messagingSenderId: "833472973108",
  
    appId: "1:833472973108:web:7040b1909f516ec4cffd61",

    vapidKey: "BPGRHfQ_oHFxGSQ7RgPmR8qmHdTa40n-Fk3tH97yrzBgbBvm8TMDXnKuXj1oJsHwpCcy8UGRXAhYmXHW_VIPxDw"
  
  },
  production: true
};
