importScripts("https://www.gstatic.com/firebasejs/9.1.3/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.1.3/firebase-messaging-compat.js");firebase.initializeApp({
    apiKey: "AIzaSyDsc_OsZCb20qMScgkCvpjkxvtg8XY4MKI",

    authDomain: "pushnotification-70393.firebaseapp.com",
  
    projectId: "pushnotification-70393",
  
    storageBucket: "pushnotification-70393.appspot.com",
  
    messagingSenderId: "833472973108",
  
    appId: "1:833472973108:web:7040b1909f516ec4cffd61"
  
});
const messaging = firebase.messaging();