export class LoginModel {
    id: number = 0;
    firstname: string = '';
    lastname: string = '';
    email: string = '';
    mobile: string = '';
    country: string = '';
    gender: string = '';
}