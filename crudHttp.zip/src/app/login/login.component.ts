import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from '../shared/api.service';
import { LoginModel } from './login.model';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private toastr: ToastrService, private api: ApiService) { }

  isSubmitted = false;
  title = 'forms';
  reactiveForm: FormGroup;
  usersData: any = [];
  posts: any;
  loginData!: any;
  loginModelObj: LoginModel = new LoginModel();

  ngOnInit() {
    this.reactiveForm = new FormGroup({
      firstname: new FormControl(null, [Validators.required]),
      lastname: new FormControl(null, [Validators.required]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      mobile: new FormControl(
        null,
        [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
      gender: new FormControl('female'),
      country: new FormControl('', [Validators.required])
    });

    this.getAllLoginDetails();
  }

  //Methods for validation
  get firstname() {
    return this.reactiveForm.get('firstname');
  }
  get lastname() {
    return this.reactiveForm.get('lastname');
  }
  get email() {
    return this.reactiveForm.get('email');
  }
  get mobile() {
    return this.reactiveForm.get('mobile');
  }
  get country() {
    return this.reactiveForm.get('country');
  }

  //for posting the data
  postLoginDetails() {
    this.isSubmitted = true;
    this.loginModelObj.firstname = this.reactiveForm.value.firstname;
    this.loginModelObj.lastname = this.reactiveForm.value.lastname;
    this.loginModelObj.email = this.reactiveForm.value.email;
    this.loginModelObj.mobile = this.reactiveForm.value.mobile;
    this.loginModelObj.country = this.reactiveForm.value.country;
    this.loginModelObj.gender = this.reactiveForm.value.gender;

    if (this.reactiveForm.valid) {
      this.api.postData(this.loginModelObj)
        .subscribe(res => {
          console.log(res);
          this.toastr.success('Data submitted successfully.');
          this.reactiveForm.reset({
            gender: 'female',
            country: ''
          });
          this.getAllLoginDetails();
          this.isSubmitted = false;
        })
    }
  }

  //Get data
  getAllLoginDetails() {
    this.api.getData()
      .subscribe(res => {
        this.loginData = res;
      })
  }

  //Delete data
  deleteLoginData(row: any) {
    this.api.deleteData(row.id)
      .subscribe(res => {
        this.toastr.warning('Data deleted successfully.');
        this.getAllLoginDetails();
      })
  }

  //Edit data
  onEdit(row: any) {
    this.loginModelObj.id = row.id;
    this.reactiveForm.controls['firstname'].setValue(row.firstname);
    this.reactiveForm.controls['lastname'].setValue(row.lastname);
    this.reactiveForm.controls['email'].setValue(row.email);
    this.reactiveForm.controls['mobile'].setValue(row.mobile);
    this.reactiveForm.controls['country'].setValue(row.country);
    this.reactiveForm.controls['gender'].setValue(row.gender);
  }

  //Update data
  updateLoginDetails() {
    this.loginModelObj.firstname = this.reactiveForm.value.firstname;
    this.loginModelObj.lastname = this.reactiveForm.value.lastname;
    this.loginModelObj.email = this.reactiveForm.value.email;
    this.loginModelObj.mobile = this.reactiveForm.value.mobile;
    this.loginModelObj.country = this.reactiveForm.value.country;
    this.loginModelObj.gender = this.reactiveForm.value.gender;

    this.api.updateData(this.loginModelObj, this.loginModelObj.id)
      .subscribe(res => {
        this.toastr.success('Data updated successfully.');
        this.reactiveForm.reset({
          gender: 'female',
          country: ''
        });
        this.getAllLoginDetails();
      })
  }
}
