let parkingLot = [
    [null, null, null, null],
    [null, null, null, null],
    [null, null, null, null],
    [null, null, null, null],
];
document.addEventListener("DOMContentLoaded", function () {
    createParkingLot();
  });
function createParkingLot() {
    let parkingLotElement = document.getElementById("parkingLot");
    for (let i = 0; i < parkingLot.length; i++) {
      let row = document.createElement("div");
      row.classList.add("row");
      for (let j = 0; j < parkingLot[i].length; j++) {
        let spot = document.createElement("div");
        spot.classList.add("spot");
        if (parkingLot[i][j] !== null) {
          spot.classList.add(parkingLot[i][j].type);
          if (parkingLot[i][j].count === 2) {
            let secondSpot = document.createElement("div");
            secondSpot.classList.add("spot");
            secondSpot.classList.add("bike");
            row.appendChild(secondSpot);
          }
        }
        row.appendChild(spot);
      }
      parkingLotElement.appendChild(row);
    }
  }

let parkingLotLength = null;
function parkCar() {
    let carpark = "yes";
    var row = parkingLot.length - 1;
    // console.log(parkingLot.length,'xyz');
    parkingLotLength = parkingLot.length;
    var col = parkingLot.length - 1;
    do {
        let vehicleType = prompt("Enter vehicle type (car/bike): ");
        let gateNumber = prompt("Enter gate number: ");
        let gateIndex;
        switch (gateNumber) {
            case "1":
                gateIndex = { row: 0, col: 0 };
                break;
            case "2":
                gateIndex = { row: 0, col: parkingLot[0].length - 1 };
                break;
            case "3":
                gateIndex = {
                    row: parkingLot.length - 1,
                    col: parkingLot[0].length - 1,
                };
                break;
            case "4":
                gateIndex = { row: parkingLot.length - 1, col: 0 };
                break;
            default:
                alert("Invalid gate number.");
                return;
        }
        let nearestRow = -1;
        let nearestCol = -1;
        let minDistance = Number.MAX_SAFE_INTEGER;
        for (let i = 0; i < parkingLot.length; i++) {
            for (let j = 0; j < parkingLot[i].length; j++) {
                if (parkingLot[i][j] === null) {
                    let distance =
                        Math.abs(i - gateIndex.row) + Math.abs(j - gateIndex.col);
                    if (distance < minDistance) {
                        nearestRow = i;
                        nearestCol = j;
                        minDistance = distance;
                    }
                }
            }
        }
        if (nearestRow === -1 && nearestCol === -1) {
            alert("Sorry, the parking lot is full.");
            return;
        }

        if (vehicleType === "bike" && parkingLot[row][col]) {
            parkingLot[row][col] = { type: vehicleType, count: 2 };
            row = parkingLot.length - 1;
            col = parkingLot.length - 1;
        }
        else if (vehicleType === "bike" && parkingLot[nearestRow][nearestCol] === null) {
            parkingLot[nearestRow][nearestCol] = { type: vehicleType, count: 1 };
            row = nearestRow;
            col = nearestCol
        }
        else if (vehicleType === "car" && parkingLot[nearestRow][nearestCol] === null) {
            parkingLot[nearestRow][nearestCol] = { type: vehicleType };
        }
        else {
            return
        }


        console.log(parkingLot);

        carpark = prompt("Do you want to park more vehicles? [Yes or No]");
    } while (carpark === "yes");
}

parkCar();
console.log("Parking Done!");

console.log(parkingLotLength);






