import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder} from '@angular/forms';
import { StudentService } from '../student.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-student',
  templateUrl: './edit-student.component.html',
  styleUrls: ['./edit-student.component.css']
})
export class EditStudentComponent implements OnInit {
editForm: FormGroup;
studentRef:any;

  constructor(private studentService: StudentService, private formBuilder: FormBuilder, private router:Router, private act: ActivatedRoute) {
    this.editForm = this.formBuilder.group({
      name: [''],
      email: [''],
      student_course: [''],
      fees: ['']
    })
   }

  ngOnInit(): void {
    const id= this.act.snapshot.paramMap.get('id');

    this.studentService.getStudentDoc(id).subscribe(res=> {
      this.studentRef = res;
      this.editForm = this.formBuilder.group({
        name:[this.studentRef.name],
        email:[this.studentRef.name],
        student_course:[this.studentRef.student_course],
        fees:[this.studentRef.fees],
      })
    })
  }
  OnSubmit(){
    const id= this.act.snapshot.paramMap.get('id');
     
    this.studentService.updateStudent(this.editForm.value, id);
    this.router.navigate(['list-student']);
  };

}
