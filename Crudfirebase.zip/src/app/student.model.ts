export class Student {
    id!: string;
    name!: string;
    email!: string;
    student_course!: string;
    fees!: string;
}
