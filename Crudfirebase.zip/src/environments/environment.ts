// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
  apiKey: "AIzaSyDxuI4zR_wr5y9e9UnZcWIRvrCykpUY6dw",
  authDomain: "crudoperation-5482c.firebaseapp.com",
  projectId: "crudoperation-5482c",
  storageBucket: "crudoperation-5482c.appspot.com",
  messagingSenderId: "413609274233",
  appId: "1:413609274233:web:4d63df66fc3a3061e55da8"
}
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
