

function validateform(){  
    event.preventDefault()
    var title = document.getElementById("title");
    var des = document.getElementById("des");
    var ap = document.getElementById("ap");
    var stat = document.getElementById("stat");
    
if(title.value.length == 0){
  document.getElementById("titleErr").innerHTML = "Please enter Title";
  return false;
}
else{
  document.getElementById("titleErr").innerHTML = "";
}

if(des.value.length == 0){
  document.getElementById("desErr").innerHTML = "Please enter Description";
  return false;
}
else{
  document.getElementById("desErr").innerHTML = "";
}

if(ap.value.length == "default"){
  document.getElementById("apErr").innerHTML = "Please select one Person";
  return false;
}
else{
  document.getElementById("apErr").innerHTML = "";
}

if(stat.value.length == "default"){
  document.getElementById("statErr").innerHTML = "Please select one Status";
  return false;
}
else{
  document.getElementById("statErr").innerHTML = "";
}

  data ={
    title : title.value,
    des : des.value,
    ap : ap.value,
    stat : stat.value,
    
  };

  console.log(data)
  title= null,
  des=null,
  ap=null,
  stat=null
  return true;
}
  

  // var listElements ; 
  function cardData(){
    let list;
    if(localStorage.getItem("list") == null){
      list = [];
    }
    else{
      list = JSON.parse(localStorage.getItem("list"));
    }
    var ToDo="";
    var InProgress="";
    var Done="";
    
    list.forEach( function(element, listpoint){
if(element.stat == "To Do"){
      ToDo += "<ul>";
      ToDo += "<li>" + element.title + "</li>";
      ToDo += "<li>" + element.des + "</li>";
      ToDo += "<li>" + element.ap + "</li>";
      ToDo += "<li>" + element.stat + "</li>";
      ToDo += '<li><button onclick="deleteData(' + listpoint + ')" Delete</button><button onclick="updateData(' + listpoint + ')" Edit</button> </li>';
      ToDo += "</ul>";
}

if(element.stat == "In Progress"){
      InProgress += "<ul>";
      InProgress += "<li>" + element.title + "</li>";
      InProgress += "<li>" + element.des + "</li>";
      InProgress += "<li>" + element.ap + "</li>";
      InProgress += "<li>" + element.stat + "</li>";
      InProgress += '<li><button onclick="deleteData(' + listpoint + ')" Delete</button><button onclick="updateData(' + listpoint + ')" Edit</button> </li>';
      InProgress += "</ul>";
    }
if(element.stat == "Done"){
      Done += "<ul>";
      Done += "<li>" + element.title + "</li>";
      Done += "<li>" + element.des + "</li>";
      Done += "<li>" + element.ap + "</li>";
      Done += "<li>" + element.stat + "</li>";
      Done += '<li><button onclick="deleteData(' + listpoint + ')" Delete</button><button onclick="updateData(' + listpoint + ')" Edit</button> </li>';
      Done += "</ul>";
}
  });
  console.log(ToDo);
// document.querySelector("#tid li").innerHTML=ToDo;
// document.querySelector("#iid li").innerHTML=InProgress;
// document.querySelector("#did li").innerHTML=Done;

    }
document.onload = cardData();



    
  
  function submit(){
    event.preventDefault()
    if(validateform() == true){
    var title = document.getElementById("title").value;
    var des = document.getElementById("des").value;
    var ap = document.getElementById("ap").value;
    var stat = document.getElementById("stat").value;

    var list;
    if(localStorage.getItem("list") == null){
      list= [];
    }
    else{
      list = JSON.parse(localStorage.getItem("list"))
    }
    list.push({
    title: title,
    des: des,
    ap: ap,
    stat: stat

    });
    localStorage.setItem("list", JSON.stringify(list));
    cardData();
    var title = document.getElementById("title").value;
    var des = document.getElementById("des").value;
    var ap = document.getElementById("ap").value;
    var stat = document.getElementById("stat").value;


  }
}
function deleteData(listpoint){
  var list;
  if(localStorage.getItem("list")==null){
    list=[];
  }
  else{
    list=JSON.parse(localStorage.getItem)("list");
  }
  list.splice(lispoint,1);
  localStorage.setItem("list",JSON.stringify(list));
  cardData();
}

  