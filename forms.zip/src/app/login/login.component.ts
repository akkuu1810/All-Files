import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private toastr: ToastrService) { }

  isSubmitted = false;
  title = 'forms';
  reactiveForm: FormGroup;
  usersData: any = [];
  private editedUser: any;

  ngOnInit() {
    this.reactiveForm = new FormGroup({
      firstname: new FormControl(null, [Validators.required]),
      lastname: new FormControl(null, [Validators.required]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      mobile: new FormControl(
        null,
        [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
      gender: new FormControl('female'),
      country: new FormControl('', [Validators.required])
    });

  }

  //Function for submitting
  onSubmit() {
    this.isSubmitted = true;
    console.log(this.reactiveForm.value);

    if (this.reactiveForm.valid) {
      let userdata = this.reactiveForm.value;
      this.usersData.push(userdata);
      this.toastr.success('Data submitted successfully.');
      this.reactiveForm.reset({
        gender: 'female',
        country: ''
      });
      this.isSubmitted = false;
    }

  }

  //For deleting
  delete(index: number) {
    if (confirm("Do you want to remove the data?")) {
      this.usersData.splice(index, 1);
      this.toastr.warning('Data deleted successfully.');
    }
  }

  //For Editting
  edit(user: any) {
    this.editedUser = user;
    this.reactiveForm.setValue({
      firstname: user.firstname,
      lastname: user.lastname,
      email: user.email,
      mobile: user.mobile,
      country: user.country,
      gender: user.gender
    })
  }

  //For Updating
  onUpdate() {
    if (this.editedUser) {
      this.usersData.map((val: any, key: number) => {
        if (this.editedUser.lastname === val.lastname) {
          this.usersData[key] = this.reactiveForm.value;
        }
      })
      this.toastr.success('Data updated successfully.');
      this.reactiveForm.reset({
        gender: 'female',
        country: ''
      });
      this.editedUser = null;
    }
  }

  //Methods for validation
  get firstname() {
    return this.reactiveForm.get('firstname');
  }
  get lastname() {
    return this.reactiveForm.get('lastname');
  }
  get email() {
    return this.reactiveForm.get('email');
  }
  get mobile() {
    return this.reactiveForm.get('mobile');
  }
  get country() {
    return this.reactiveForm.get('country');
  }

}



