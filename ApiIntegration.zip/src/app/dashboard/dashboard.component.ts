import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminService } from '../shared/admin.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Data } from './data';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  data: any;
  DataObj: Data = new Data();
  form!: FormGroup;
  page: number = 1;
  count: number = 0;
  tableSize: number = 10;
  tableSizes: any = [10, 20, 50, 100];

  playlist: any;
  isAdded = false;

  post: any = {
    title: '',
    image_path: ''
  }

  constructor(private router: Router, private toastr: ToastrService, private adminService: AdminService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      title: new FormControl(null, [Validators.required]),
      image_path: new FormControl(null, [Validators.required]),
    });
    this.fetchData(this.page);
    this.add();
  }

  //logout function
  logout() {
    localStorage.removeItem("token");
    this.toastr.warning("Logged Out");
    this.router.navigate(['/login']);
  }

  //Get Data
  fetchData(pageIndex) {
    this.adminService.getPlaylist(pageIndex).subscribe((playlist: any) => {
      this.data = playlist.data.data;
      this.count = playlist.data.total;
      this.page = pageIndex;
    })
  }

  //Add Data
  add() {
    const data = {
      title: this.form.value.title,
      image_path: this.form.value.image_path
    };
    this.adminService.addPlaylist(data).subscribe((res: any) => {
      console.log(res);
      this.isAdded = true;
      this.toastr.success("Data Added Successfully");
      this.fetchData(this.page);
      this.form.reset();
    });
  }

  //Edit Data
  edit(row: any) {
    this.DataObj.id = row.id;
    this.form.controls['title'].setValue(row.title);
    this.form.controls['image_path'].setValue(row.image_path);
    // this.form.reset();
  }

  //Delete Data
  delete(row: any) {
    if (window.confirm('Are you sure you want to delete?')) {
      this.adminService.deletePlaylist(row.id)
        .subscribe(res => {
          this.toastr.warning('Data deleted successfully.');
          this.fetchData(this.page);
        })
    }
  }

  //Update Data
  update() {
    console.log(this.DataObj)
    this.adminService.updatePlaylist(this.DataObj.id, this.form)
      .subscribe(res => {
        this.toastr.success('Data updated successfully.');
        this.fetchData(this.page)
      })
    this.form.reset();
  }

  //Pagination
  onTableDataChange(event: any) {
    this.page = event;
    this.fetchData(this.page);
  }
  onTableSizeChange(event: any): void {
    console.log("page1", event);
    this.tableSize = event.target.value;
    this.page = this.count;
    this.fetchData(this.page);
  }

  cancel() {
    this.form.reset();
  }
}
