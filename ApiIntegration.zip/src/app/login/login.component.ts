import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminService } from '../shared/admin.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  isSubmitted = false;
  form: FormGroup;
  constructor(private router: Router, private adminService: AdminService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(
        null,
        Validators.required)
    });
  }

  // Methods for Validation
  get email() {
    return this.form.get('email');
  }
  get password() {
    return this.form.get('password');
  }

  onSubmit(data: any) {
    this.isSubmitted = true;
    console.log(data);
    if(this.form.valid){

    
    this.adminService.login(data).subscribe((result: any) => {
      console.log("result", result.data)
      localStorage.setItem("token", result.data.access_token);
      localStorage.setItem("firstname", result.data.data.first_name);
      localStorage.setItem("lastname", result.data.data.last_name);
      this.toastr.success("Logged In SuccessFully");
      this.router.navigate(['/dashboard']);
    },err=>{
      this.toastr.error(err.error.message);
      this.router.navigate(['/login']);
    })
  }
  }

}
