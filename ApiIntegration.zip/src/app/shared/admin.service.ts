import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { map } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient) { }

  // headers = new HttpHeaders({
  //   'Accept': 'application/json',
  //   'Authorization': 'Bearer' + localStorage.getItem('token')
  // })


  login(data: any) {
    return this.http.post("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/login", data)
  }

  changePassword(data: any) {
    let token = localStorage.getItem("token")
    const headers = new HttpHeaders().set('Authorization', `bearer ${token}`);
    return this.http.post('https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/change-password', data, { headers: headers });
  }

  getData() {
    let token = localStorage.getItem("token")
    const headers = new HttpHeaders().set('Authorization', `bearer ${token}`);
    return this.http.get<any>("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/userList", { headers: headers })
      .pipe(map((res: any) => {
        return res;
      }));
  }

  getPlaylist(pageIndex) {
    return this.http.get("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/playlist?page="+pageIndex)
  }

  addPlaylist(data: any) {
    return this.http.post("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/storeplaylist", data);
  }

  deletePlaylist(id: any) {
    return this.http.delete(`https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/deleteplaylist/${id}`);
  }

  getList(id: any) {
    return this.http.get(`https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/editplaylist/${id}`);
  }

  updatePlaylist(id: any, data: any) {
    return this.http.post(`https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/updateplaylist/${id}`,data.value);
  }
}
