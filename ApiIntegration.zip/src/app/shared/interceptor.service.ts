import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor {
  token = localStorage.getItem("token");
  constructor() { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let jwtToken = req.clone({
      setHeaders: {
        Authorization: 'Bearer ' + this.token
      }
    })
    return next.handle(jwtToken).pipe(
      catchError((error: HttpErrorResponse) => {
        let errormsg = '';
        if (error.error instanceof ErrorEvent) {
          errormsg = `Client Side Error : ${error.error.message}`
        }
        else {
          errormsg = `Server Error: ${error.error.msg}`
        }
        return throwError(errormsg);
      })
    )
  }
}
