import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  url: string = environment.apiUrl;
  isSubmitted = false;
  form!: FormGroup;

  constructor(private toastr: ToastrService, private router: Router, private http: HttpClient) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      firstname: new FormControl(null, [Validators.required]),
      lastname: new FormControl(null, [Validators.required]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null, [Validators.required]),
      confirmpassword: new FormControl(null, [Validators.required]),
      mobile: new FormControl(
        null,
        [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
      subtype: new FormControl(null, [Validators.required]),
    });
  }

  //Methods for validation
  get firstname() {
    return this.form.get('firstname');
  }
  get lastname() {
    return this.form.get('lastname');
  }
  get email() {
    return this.form.get('email');
  }
  get password() {
    return this.form.get('password');
  }
  get confirmpassword() {
    return this.form.get('password');
  }
  get mobile() {
    return this.form.get('mobile');
  }
  get subtype() {
    return this.form.get('subtype');
  }


  postLoginDetails() {
    this.isSubmitted = true;
    if (this.form.valid) {
      var formData: any = new FormData();
      formData.append('first_name', this.form.get('firstname').value);
      formData.append('last_name', this.form.get('lastname').value);
      formData.append('email', this.form.get('email').value);
      formData.append('phone_number', this.form.get('mobile').value);
      formData.append('password', this.form.get('password').value);
      formData.append('password_confirmation', this.form.get('confirmpassword').value);
      formData.append('subscription_type', this.form.get('subtype').value);


      this.http
        .post<any>(this.url + '/v1/register', formData)
        .subscribe({
          next: (response: any) => {
            this.toastr.success("Data Submitted Successfully")
            this.router.navigate(['/login']);
          },
          error: (error: any) => this.toastr.error(error),
        });

    }
  }
}
