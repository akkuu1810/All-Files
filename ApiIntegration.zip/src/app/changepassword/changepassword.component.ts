import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminService } from '../shared/admin.service';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  isSubmitted = false;
  form: FormGroup;
  constructor(private http: HttpClient, private toastr: ToastrService, private router: Router, private adminService: AdminService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      password: new FormControl(null, Validators.required),
      confirmpassword: new FormControl(null, Validators.required),
      newPassword: new FormControl(null, Validators.required)
    });
  }

  // Methods for Validation
  get password() {
    return this.form.get('password');
  }
  get confirmpassword() {
    return this.form.get('confirmpassword');
  }
  get newPassword() {
    return this.form.get('newPassword');
  }

  //Function for changing the password
  changePassword() {
    this.isSubmitted = true;
    if (this.form.valid) {
      var formData: any = new FormData();
      formData.append('password', this.form.get('password').value);
      formData.append('password_confirmation', this.form.get('confirmpassword').value);
      formData.append('newpassword', this.form.get('newPassword').value);

      this.adminService.changePassword(formData).subscribe({
        next: (response) => console.log(response),
        error: (error) => console.log(error)
      });
      this.toastr.success("Password changed Successfully")
    }
  }
}
