export const locale = {
  lang: 'en',
  data: {
    HEADER: {
      NAME: 'NAME',
      EMAIL: 'EMAIL',
      AGE: 'AGE',
      STATUS: 'STATUS',
      ACTIONS: 'ACTIONS'
    }
  }
};
