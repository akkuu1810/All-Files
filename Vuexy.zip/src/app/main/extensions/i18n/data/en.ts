export const locale = {
  lang: 'en',
  data: {
    CARD: {
      TITLE: 'Title',
      TEXT:
        'Clean, commented and well formatted code structure enables you to quick start your project in no time. The template provides great customization, and allows you to make it your own with the use of different modular elements and the customization of the SASS files. Great combination of features, components and modern design'
    }
  }
};
