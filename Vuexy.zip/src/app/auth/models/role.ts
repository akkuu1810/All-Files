﻿export enum Role {
  Admin = 'Admin',
  Client = 'Client',
  User = 'User'
}
