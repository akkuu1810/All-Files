export interface Details {
    id: string,
    firstname: string,
    lastname: string,
    email: string,
    mobile: string,
    age:string,
    
}