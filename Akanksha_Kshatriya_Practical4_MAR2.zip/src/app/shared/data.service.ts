import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Details } from '../model/details';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private afs: AngularFirestore) { }

  //add details
  addDetails(details: Details) {
    details.id = this.afs.createId();
    return this.afs.collection('/Details').add(details);
  }

  //get all details
  getAllDetails() {
    return this.afs.collection('/Details').snapshotChanges();
  }

  //delete details
  deleteDetails(details: Details) {
    return this.afs.doc('/Details/' + details.id).delete();
  }

  //update details
  updateDetails(details: Details) {
   
    return this.afs.doc('/Details/' + details.id).update(details);
  }
}
