import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { GoogleAuthProvider } from '@angular/fire/auth';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private fireAuth: AngularFireAuth, private router: Router, private toastr: ToastrService) { }

  // login method

  login(email: any, password: any) {
    this.fireAuth.signInWithEmailAndPassword(email, password).then(res => {
      localStorage.setItem('token', 'true');

      if (res.user?.emailVerified == true) {
        this.router.navigate(['dashboard']);
      } else {
        this.router.navigate(['/verify-email']);
      }
    }, err => {
      this.toastr.error("There was some Error");
      this.router.navigate(['/login']);
    })
  }

  //register method
  register(email: any, password: any, firstname: any, lastname: any, mobile: any, age: any) {
    this.fireAuth.createUserWithEmailAndPassword(email, password).then(res => {
      alert('Registration is successfull');
      this.router.navigate(['/login']);
      this.sendEmailForVerification(res.user);
    }, err => {
      this.toastr.error("There was some Error");
      this.router.navigate(['/register']);
    })
  }

  //sign out
  logout() {
    this.fireAuth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['/login']);
    }, err => {
      this.toastr.error("There was some Error");
    })
  }

  //forgot password
  forgotPassword(email: string) {
    this.fireAuth.sendPasswordResetEmail(email).then(() => {
      this.router.navigate(['/verify-email']);
    }, err => {
      this.toastr.error("There was some Error");
    })
  }

  //for verification
  sendEmailForVerification(user: any) {
    user.sendEmailVerification().then((res: any) => {
      this.router.navigate(['verify-email']);
    }, (err: any) => {
      this.toastr.error("There was some Error");
    })
  }

  // sign in with google
  googleSignIn() {
    return this.fireAuth.signInWithPopup(new GoogleAuthProvider).then(res => {
      this.router.navigate(['/dashboard']);
      localStorage.setItem('token', JSON.stringify(res.user?.uid));
    }, err => {
      this.toastr.error("There was some Error");
    })
  }

  //for authentication
  IsloggedIn() {
    return localStorage.getItem('token');
  }
}
