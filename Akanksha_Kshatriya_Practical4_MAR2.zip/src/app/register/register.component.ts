import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Details } from '../model/details';
import { AuthService } from '../shared/auth.service';
import { DataService } from '../shared/data.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  isSubmitted = false;
  form!: FormGroup;
  hide: any;


  constructor(private data: DataService, private router: Router, private auth: AuthService,private toastr: ToastrService) { }

  ngOnInit(): void {

    this.form = new FormGroup({
      firstname: new FormControl('', Validators.required),
      lastname: new FormControl('', Validators.required),
      age: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      mobile: new FormControl('', [
        Validators.required,
        Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
      ]),
    });

  }

  get firstname() {
    return this.form.get('firstname');
  }
  get lastname() {
    return this.form.get('lastname');
  }
  get email() {
    return this.form.get('email')
  }
  get mobile() {
    return this.form.get('mobile');
  }
  get age() {
    return this.form.get('age');
  }
  get password() {
    return this.form.get('password');
  }

  register() {
    let data = this.form.value;
    console.log(data);

    if (this.form.valid) {
      this.auth.register(data.email, data.password, data.firstname, data.lastname, data.mobile, data.age);
      this.toastr.success("Registered Successfully");
      this.router.navigate(['login']);
    } else {
    }
    this.isSubmitted = true;

  }
  login() {
    this.toastr.success("LoggedIn Successfully")
    this.router.navigate(['login']);
  }

}
