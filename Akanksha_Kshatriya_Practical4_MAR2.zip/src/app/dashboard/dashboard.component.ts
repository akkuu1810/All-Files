import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Details } from '../model/details';
import { DataService } from '../shared/data.service';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  displayedColumns: string[] = ['firstname', 'lastname', 'email', 'mobile', 'age', 'action'];


  @ViewChild(MatPaginator)
  paginator!: MatPaginator;

  detailsList: Details[] = [];
  isSubmitted = false;
  users: any = [];
  editedUser: any;
  first_name: any;
  last_name: any;
  form!: FormGroup;
  isHidden: any;
  value: any;
  user: any;
  isEdit = false;
  dataSource = new MatTableDataSource([]);

  DataObj: Details = {
    id: '',
    firstname: '',
    lastname: '',
    email: '',
    age: '',
    mobile: '',
  };
  details: Details;

  constructor(private data: DataService, private router: Router, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.dataSource.paginator = this.paginator;
    this.form = new FormGroup({
      firstname: new FormControl('', Validators.required),
      lastname: new FormControl('', Validators.required),
      age: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      mobile: new FormControl('', [
        Validators.required,
        Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
      ]),
    });
    this.getAllDetails();
    this.user = localStorage.getItem('user');
    console.warn(this.user)
  }

  get firstname() {
    return this.form.get('firstname');
  }
  get lastname() {
    return this.form.get('lastname');
  }
  get email() {
    return this.form.get('email')
  }
  get mobile() {
    return this.form.get('mobile');
  }
  get age() {
    return this.form.get('age');
  }

  //Get Method
  getAllDetails() {
    this.isSubmitted = true;

    this.data.getAllDetails().subscribe(
      (res: any) => {
        this.detailsList = res.map((e: any) => {
          const data = e.payload.doc.data();
          data.id = e.payload.doc.id;

          console.log(data)
          return data;
        });
        this.dataSource.data = this.detailsList;
        this.dataSource.paginator = this.paginator;

      },
      (err) => {
        this.toastr.error("Error while fetching student data");
      }
    );
    this.isSubmitted = false;
  }

  //Add Method
  addDetails() {
    this.isSubmitted = true;
    this.DataObj.id = '';
    this.DataObj.firstname = this.form.value.firstname;
    this.DataObj.lastname = this.form.value.lastname;
    this.DataObj.email = this.form.value.email;
    this.DataObj.mobile = this.form.value.mobile;
    this.DataObj.age = this.form.value.age;
    console.log('key', this.form);
    if (this.form.valid) {
      this.data.addDetails(this.DataObj);
      this.toastr.success("Data Added Successfully")
      this.form.reset();
    }
  }

  //Delete Method
  deleteDetails(details: Details) {
    if (
      window.confirm(
        'Are you sure you want to delete ' +
        details.firstname +
        ' ' +
        details.lastname +
        ' ?'
      )
    ) {
      this.data.deleteDetails(details);
      this.toastr.success("Data Deleted Successfully")
    }
  }

  //Edit Method
  onEdit(details: any) {
    this.isHidden = true;
    this.isEdit = true;
    this.DataObj.id = details.id;
    this.form.controls['firstname'].setValue(details.firstname);
    this.form.controls['lastname'].setValue(details.lastname);
    this.form.controls['email'].setValue(details.email);
    this.form.controls['mobile'].setValue(details.mobile);
    this.form.controls['age'].setValue(details.age);
  }

  //Update Method
  updateDetails() {
    this.DataObj.id = this.DataObj.id;
    this.DataObj.firstname = this.form.value.firstname;
    this.DataObj.lastname = this.form.value.lastname;
    this.DataObj.email = this.form.value.email;
    this.DataObj.mobile = this.form.value.mobile;
    this.DataObj.age = this.form.value.age;
    this.data.updateDetails(this.DataObj);
    this.toastr.success("Data Updated Successfully");
  }

  //Logout method
  logout() {
    localStorage.removeItem('token')
    this.toastr.warning("User Logged Out")
    this.router.navigate(['/login'])
  }

  display() {
    this.isHidden = true;
  }

  cancel() {
    this.isHidden = false;
    this.form.reset();
    this.isEdit = false;
  }

  //Search
  public doFilter(value: any) {
    console.log(value.value)
    this.dataSource.filter = value.value.trim().toLowerCase();
  }
}


