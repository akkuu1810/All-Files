// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDPXs6IG0fT6ByTHlyAnbANtCMzKbwkrH8",

    authDomain: "crud-d43cc.firebaseapp.com",

    projectId: "crud-d43cc",

    storageBucket: "crud-d43cc.appspot.com",

    messagingSenderId: "790463801402",

    appId: "1:790463801402:web:f19c31569f5a18aff42d03"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
