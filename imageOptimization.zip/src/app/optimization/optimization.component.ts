import { Component, OnInit } from '@angular/core';
import { NgOptimizedImage } from '@angular/common'

@Component({
  selector: 'app-optimization',
  templateUrl: './optimization.component.html',
  styleUrls: ['./optimization.component.css']
})
export class OptimizationComponent implements OnInit {

  imageSrc = '../assets/cat2.jpg';
  messageText = '';
  imageButtons = [ { src: '../assets/cat3.webp', name: 'image-2' }]
  img: any;
  constructor() { }
  ngOnInit() {
  }
  onClick(imageNameObject: any) {
    this.imageSrc = imageNameObject.src;
    this.messageText = imageNameObject.name;
  }
  valid(event: any) {
    event.target.src = "https://is2-ssl.mzstatic.com/image/thumb/Purple112/v4/78/d8/9f/78d89ff3-73df-dd84-9c46-37bc9db450cd/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/512x512bb.jpg"
  }

}
