import { Details } from './../../model/details';
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/shared/auth.service';
import { DataService } from 'src/app/shared/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  detailsList: Details[] = [];
  detailsObj: Details = {
    id: '',
    first_name: '',
    last_name: '',
    email: '',
    mobile: '',
  };
  id: string = '';
  first_name: string = '';
  last_name: string = '';
  email: string = '';
  mobile: string = '';

  constructor(private auth: AuthService, private data: DataService, private router: Router) { }

  ngOnInit(): void {
    this.getAllDetails();
  }

  // register(){
  //   this.auth.logout();
  // }

  getAllDetails() {
    this.data.getAllDetails().subscribe(
      (res) => {
        this.detailsList = res.map((e: any) => {
          const data = e.payload.doc.data();
          data.id = e.payload.doc.id;
          return data;
        });
      },
      (err) => {
        alert('Error while fetching details');
      }
    );
  }

  resetForm() {
    this.id = '';
    this.first_name = '';
    this.last_name = '';
    this.email = '';
    this.mobile = '';
  }

  addDetails() {
    if (
      this.first_name == '' ||
      this.last_name == '' ||
      this.email == '' ||
      this.mobile == ''
    ) {
      alert('Fill all the values');
    }
    else {
      this.detailsObj.id = '';
      this.detailsObj.email = this.email;
      this.detailsObj.first_name = this.first_name;
      this.detailsObj.last_name = this.last_name;
      this.detailsObj.mobile = this.mobile;

      this.data.addDetails(this.detailsObj);
      this.resetForm();
    }
  }

  updateDetails() {
    this.detailsObj.id = this.id;
    this.detailsObj.email = this.email;
    this.detailsObj.first_name = this.first_name;
    this.detailsObj.last_name = this.last_name;
    this.detailsObj.mobile = this.mobile;
    this.data.updateDetails(this.detailsObj);
  }

  deleteDetails(details: Details) {
    if (
      window.confirm(
        'Are you sure you want to delete ' +
        details.first_name +
        ' ' +
        details.last_name +
        ' ?'
      )
    ) {
      this.data.deleteDetails(details);
    }
  }

  editDetails(details: any) {
    this.id = details.id;
    this.email = details.email;
    this.first_name = details.first_name;
    this.last_name = details.last_name;
    this.mobile = details.mobile;
  }

  logout() {
    localStorage.removeItem('token')
    this.router.navigate(['/login'])
  }
}