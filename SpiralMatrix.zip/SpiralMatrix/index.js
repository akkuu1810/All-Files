function matrix() {
    let result = new Array(n).fill().map(() => new Array(n).fill(''));

    let counter = 1;
    let startCol = 0;
    let endCol = n - 1;
    let startRow = 0;
    let endRow = n - 1;

    while (startCol <= endCol && startRow <= endRow) {
        for (let i = startCol; i <= endCol; i++) {
            result[startRow][i] = counter;
            counter++;
        }
        startRow++;
        for (let j = startRow; j <= endRow; j++) {
            result[j][endCol] = counter;
            counter++;
        }

        endCol--;

        for (let i = endCol; i >= startCol; i--) {
            result[endRow][i] = counter;
            counter++;
        }

        endRow--;
        for (let i = endRow; i >= startRow; i--) {
            result[i][startCol] = counter;
            counter++;
        }

        startCol++;

    }
    console.log('result: ', result);
    return result;
}

var n = parseInt(prompt("Please enter no. for matrix you want",
    6));

const x = matrix(n);

const table = document.createElement("table");
table.style.margin = 'auto';
table.style.border = '1px solid black';

for (let i = 0; i < n; i++) {
    const tr = document.createElement("tr");

    for (let j = 0; j < n; j++) {
        const td = document.createElement("td");
        td.textContent = x[i][j];
        td.style.border = ' 1px solid black '
        td.style.borderStyle = 'double'
        td.style.borderWidth = 'thick'
        td.style.width = '60px'
        td.style.height = '50px'
        td.style.alignContent = 'center'
        td.style.textAlign = 'center'
        td.style.fontSize = '20px'
        td.style.backgroundColor = '#FFFFD5'
        // table.style.marginTop = '100px'
        tr.appendChild(td);
    }
    table.appendChild(tr);
}
document.body.appendChild(table)

