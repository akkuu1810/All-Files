import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mytask',
  templateUrl: './mytask.component.html',
  styleUrls: ['./mytask.component.css']
})
export class MytaskComponent implements OnInit {

  // myStyles = {
  //   width: '500px',
    
  //   background: 'red'
  // }
  model: any;
  constructor() { }

  ngOnInit(): void {
    this.model=
    [
      {
        firstname:'akanksha',
        lastname:'kshatriya',
        age:21,
        date:'2001/10/18'
      },
      {
        firstname:'ttt',
        lastname:'vvv',
        age:22,
        date:'2000/10/10'
      },
      {
        firstname:'abc',
        lastname:'xyz',
        age:23,
        date:'1999/11/18'
      },
      {
        firstname:'aaa',
        lastname:'bbb',
        age:20,
        date:'2002/12/18'
      },
      {
        firstname:'qqq',
        lastname:'zzz',
        age:24,
        date:'1998/10/15'
      },
      {
        firstname:'hhh',
        lastname:'iii',
        age:22,
        date:'2000/10/20'
      },
      {
        firstname:'ggg',
        lastname:'kkk',
        age:22,
        date:'2000/10/16'
      },
      {
        firstname:'eee',
        lastname:'ddd',
        age:23,
        date:'1999/10/17'
      },
      {
        firstname:'fff',
        lastname:'jjj',
        age:21,
        date:'2001/10/20'
      },
      {
        firstname:'ooo',
        lastname:'uuu',
        age:22,
        date:'2000/10/21'
      }
    ]

    
  }
 


}
